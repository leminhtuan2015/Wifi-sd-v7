var newestImageName = 'file name';
var indexMax = 0;

function getFileNames(host, folder, callback) {
	alert("Detecting newest image ...|" + host + folder);
	$.ajax({
		url : host + folder + "",
		// url: "loaclhost",
		type : 'GET',
		dataType : 'jsonp',
		crossDomain : true,
		beforeSend : function() {
			alert("before");
		},
		success : function(data) {
			alert(data);

			$(data).find("td:contains(2013)").each(function() {
				// Alert date
				// alert("date : " + $(this).html());
			});

			$(data).find("a:contains(.JPG)").each(function(index, domEle) {
				indexMax = index;
			});

			// alert(indexMax+"");

			$(data).find("a:contains(.JPG)").each(function(index, domEle) {
				if (index == indexMax) {
					alert("image : " + $(this).attr("href"));
					newestImageName = $(this).attr("href");
					// callback(newestImageName);
				}
			});
		},
		error : function() {
			alert("err");
		}

	});
}

function getFileNamesJsonp(host, folder, callback) {
	alert(host+folder);
	$.getJSON(
			"http://api.flickr.com/services/feeds/photos_public.gne?jsoncallback=?",
//			"http://www.jquery4u.com/function-demos/jsonp?jsoncallback=?",
			 {
                tags: "jquery",
                tagmode: "any",
                format: "html"
              },
			
			function(data) {
               alert("callback");
               alert(data);
               $.each(data.items, function(i,item){
            	   alert("index : "+i + " : " + item.link);
                 });
            }
      );
}
