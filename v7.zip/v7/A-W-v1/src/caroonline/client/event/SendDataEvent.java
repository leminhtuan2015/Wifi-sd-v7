package caroonline.client.event;

import caroonline.client.modal.Position;
import caroonline.shared.Data;

import com.google.gwt.event.shared.GwtEvent;

public class SendDataEvent extends GwtEvent<SendDataEventHandle>  {
	
	Position position;
	public SendDataEvent(Position position) {
		this.position = position;
	}

	public static Type<SendDataEventHandle> type = new Type<SendDataEventHandle>();
	
	@Override
	public com.google.gwt.event.shared.GwtEvent.Type<SendDataEventHandle> getAssociatedType() {
		return type;
	}

	@Override
	protected void dispatch(SendDataEventHandle handler) {
		handler.onSendData(position);
	}

}
