package caroonline.client.event;

import caroonline.client.modal.Position;
import caroonline.shared.Data;

import com.google.gwt.event.shared.EventHandler;

public interface SendDataEventHandle extends EventHandler {

	public void onSendData(Position position);
}
