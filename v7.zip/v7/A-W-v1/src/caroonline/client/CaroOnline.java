package caroonline.client;

import javax.validation.constraints.NotNull;

import caroonline.client.activities.AppActivityMapper;
import caroonline.client.activities.AppHistoryObserver;
import caroonline.client.activities.AppPlaceHistoryMapper;
import caroonline.client.activities.ClientFactory;
import caroonline.client.activities.ClientFactoryImpl;
import caroonline.client.activities.game.GamePlace;
import caroonline.client.activities.home.HomePlace;
import caroonline.client.socket.SocketManager;

import com.google.gwt.activity.shared.ActivityManager;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.GWT.UncaughtExceptionHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.place.shared.PlaceHistoryMapper;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.SimplePanel;
import com.googlecode.gwtphonegap.client.PhoneGap;
import com.googlecode.mgwt.mvp.client.AnimatableDisplay;
import com.googlecode.mgwt.mvp.client.history.HistoryObserver;
import com.googlecode.mgwt.mvp.client.history.MGWTPlaceHistoryHandler;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class CaroOnline implements EntryPoint {

	private final GreetingServiceAsync greetingService = GWT
			.create(GreetingService.class);
	
	SimplePanel display = new SimplePanel();
	
	PlaceHistoryMapper historyMapper = GWT.create(AppPlaceHistoryMapper.class);
	HistoryObserver historyObserver = new AppHistoryObserver();
	
	public static ClientFactory clientFactory ;
	public static AppActivityMapper appActivityMapper ;
	public static SocketManager socketManager;
	public static PhoneGap phoneGap = GWT.create(PhoneGap.class);
	
	public CaroOnline() {
		 clientFactory = new ClientFactoryImpl();
		 appActivityMapper = new AppActivityMapper(clientFactory);
		 socketManager = new SocketManager();
	}

	public void onModuleLoad() {
		 GWT.setUncaughtExceptionHandler(new UncaughtExceptionHandler() {
				
			@Override
			public void onUncaughtException(@NotNull Throwable e) {
				clientFactory.getPlaceController().goTo(new HomePlace());
			}
		});
		 
		 registyHistoryPlaceHandle();
		 registryActivityMapper();
		 
		 RootPanel.get().add(display);
		 
		 clientFactory.getPlaceController().goTo(new HomePlace());
	}
	
	private void registyHistoryPlaceHandle(){
		MGWTPlaceHistoryHandler historyHandler = new MGWTPlaceHistoryHandler(historyMapper, historyObserver);
	    historyHandler.register(clientFactory.getPlaceController(), clientFactory.getEventBus(),
			        new HomePlace());
		 historyHandler.handleCurrentHistory();
	}
	private void registryActivityMapper(){
		 ActivityManager activityManager = new ActivityManager(appActivityMapper, clientFactory.getEventBus());
		 activityManager.setDisplay(display);
	} 
}
