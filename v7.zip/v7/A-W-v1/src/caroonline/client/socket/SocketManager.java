package caroonline.client.socket;

import caroonline.client.CaroOnline;

import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.googlecode.mgwt.ui.client.widget.touch.TouchPanel;

public class SocketManager {
	
	public static final String SOCKET_SERVER = "TUAN.SOCKET.SERVER";

	/*
	 * open socket
	 * registry event receive message with id  
	 * server socket use id to send message
	 * */
	public native void openSocket(String id)/*-{
		var app = this;
		$wnd.openSocketToServer(id,function(fromUser,content){
		 app.@caroonline.client.socket.SocketManager::receiveMessage(Ljava/lang/String;Ljava/lang/String;)(fromUser,content);
		});
	}-*/;

	public native void sendMessage(String to,String content) /*-{
		var app = this;
		$wnd.sendMessage(to,content);
	}-*/;
	
	private void receiveMessage(String fromUser,String content){
		Window.alert(fromUser+" java show");
	}

}
