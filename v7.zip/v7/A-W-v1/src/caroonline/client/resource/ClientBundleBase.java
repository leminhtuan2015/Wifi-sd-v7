package caroonline.client.resource;

import com.google.gwt.resources.client.ImageResource;

public interface ClientBundleBase {
	ImageResource hold();
	
	ImageResource sword();

	ImageResource gold();
	
	ImageResource mana();
	
	ImageResource insure();
	
	ImageResource lightning();
	
	ImageResource blood();
	
	ImageResource exp();
}
