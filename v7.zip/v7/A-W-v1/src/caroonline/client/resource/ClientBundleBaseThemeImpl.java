package caroonline.client.resource;

import com.google.gwt.core.shared.GWT;

public class ClientBundleBaseThemeImpl {

	private static ClientBundleBaseTheme clientBundleBaseTheme;
	
	public static ClientBundleBaseTheme getClientBundleBaseTheme(){
		if(clientBundleBaseTheme == null){
			clientBundleBaseTheme = GWT.create(ClientBundleBaseTheme.class);
		}
		
		return clientBundleBaseTheme;
	}
}
