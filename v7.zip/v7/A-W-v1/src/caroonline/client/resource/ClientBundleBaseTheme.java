package caroonline.client.resource;

import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

public interface ClientBundleBaseTheme extends ClientBundle,ClientBundleBase{

	@Source("css/add-image.png")
	public ImageResource hold();

	@Source("css/sword.png")
	public ImageResource sword();
	
	@Source("css/gold.png")
	public ImageResource gold();
	
	@Source("css/mana.png")
	public ImageResource mana();
	
	@Source("css/insure.png")
	public ImageResource insure();
	
	@Source("css/lightning.png")
	public ImageResource lightning();
	
	@Source("css/blood.png")
	public ImageResource blood();
	
	@Source("css/exp.png")
	public ImageResource exp();
}

