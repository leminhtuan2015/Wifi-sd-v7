package caroonline.client.activities.basic;

import com.google.gwt.user.client.ui.HasText;
import com.google.gwt.user.client.ui.IsWidget;
import com.googlecode.mgwt.ui.client.widget.HeaderButton;
import com.googlecode.mgwt.ui.client.widget.HeaderPanel;
import com.googlecode.mgwt.ui.client.widget.LayoutPanel;
import com.googlecode.mgwt.ui.client.widget.ScrollPanel;
import com.googlecode.mgwt.ui.client.widget.WidgetList;

public interface BasicView extends IsWidget{
	public HasText getHeader();
	public HasText getBackButtonText();
	public HeaderButton getBackButton();
	public HasText getHomeButtonText();
	public HeaderButton getHomeButton();
	public LayoutPanel getLayoutPanel();
	public ScrollPanel getScrollPanel();
	public void setHomeButtonText(String text);
	public void setTitle(String title);
	public void setBackButtonText(String text);
	public HeaderPanel getHeaderPanel();
	public WidgetList getWidgetList();
}
