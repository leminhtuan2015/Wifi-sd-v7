package caroonline.client.activities.basic;

import caroonline.client.activities.ClientFactory;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.googlecode.mgwt.mvp.client.MGWTAbstractActivity;

public class BasicActivity extends MGWTAbstractActivity {
	
	protected final ClientFactory clientFactory;
	
	public BasicActivity(ClientFactory clientFactory) {
		this.clientFactory = clientFactory;
	}

	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {		
	}

}
