package caroonline.client.activities.basic;

import com.google.gwt.place.shared.Place;
import com.google.gwt.place.shared.PlaceTokenizer;

public class BasicPlace extends Place {
	
	protected String token = this.getClass().getName();
	
	public BasicPlace() {
	}
	
	public String getToken(){
		return token;
	}
	
	
	public static class Tokenizer implements PlaceTokenizer<BasicPlace> {
        @Override
        public String getToken(BasicPlace place) {
            return place.getToken();
        }

        @Override
        public BasicPlace getPlace(String token) {
            return new BasicPlace();
        }
    }

}
