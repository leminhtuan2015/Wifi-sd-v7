package caroonline.client.activities.basic;

import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasText;
import com.google.gwt.user.client.ui.Widget;
import com.googlecode.mgwt.ui.client.widget.HeaderButton;
import com.googlecode.mgwt.ui.client.widget.HeaderPanel;
import com.googlecode.mgwt.ui.client.widget.LayoutPanel;
import com.googlecode.mgwt.ui.client.widget.ScrollPanel;
import com.googlecode.mgwt.ui.client.widget.WidgetList;

public class BasicViewImpl implements BasicView{
	protected LayoutPanel main;
	protected ScrollPanel scrollPanel;
	protected HeaderPanel headerPanel;
	protected HeaderButton headerBackButton;
	protected HeaderButton headerHomeButton;
	protected WidgetList widgetList;
	protected HTML title;
	
	public BasicViewImpl() {
		main = new LayoutPanel();
		scrollPanel = new ScrollPanel();
		headerPanel = new HeaderPanel();
		headerBackButton = new HeaderButton();
		headerHomeButton = new HeaderButton();
		widgetList = new WidgetList();
		title = new HTML();
		
		headerPanel.setRightWidget(headerHomeButton);
		headerPanel.setLeftWidget(headerBackButton);
		headerPanel.setCenterWidget(title);
		
		headerHomeButton.setText("Home");
		headerBackButton.setText("Back");
		
		scrollPanel.add(widgetList);
		
		main.add(headerPanel);
		main.add(scrollPanel);
	}

	@Override
	public Widget asWidget() {
		return main;
	}

	@Override
	public HasText getHeader() {
		return title;
	}

	@Override
	public HasText getBackButtonText() {
		return headerBackButton;
	}

	@Override
	public HeaderButton getBackButton() {
		return headerBackButton;
	}

	@Override
	public HasText getHomeButtonText() {
		return headerHomeButton;
	}

	@Override
	public HeaderButton getHomeButton() {
		return headerHomeButton;
	}

	@Override
	public LayoutPanel getLayoutPanel() {
		return main;
	}

	@Override
	public ScrollPanel getScrollPanel() {
		return scrollPanel;
	}

	@Override
	public void setHomeButtonText(String text) {
		headerHomeButton.setText(text);
	}

	@Override
	public void setTitle(String title) {
		headerPanel.setTitle(title);
	}

	@Override
	public void setBackButtonText(String text) {
		headerBackButton.setText(text);
	}

	@Override
	public HeaderPanel getHeaderPanel() {
		return headerPanel;
	}

	@Override
	public WidgetList getWidgetList() {
		return widgetList;
	}

}
