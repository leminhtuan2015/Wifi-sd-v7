package caroonline.client.activities.gps;

import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;

import caroonline.client.CaroOnline;
import caroonline.client.activities.basic.BasicViewImpl;
import caroonline.client.activities.game.GamePlace;
import caroonline.client.event.SendDataEvent;
import caroonline.client.event.SendDataEventHandle;
import caroonline.client.modal.Position;

public class GpsViewImpl  extends BasicViewImpl implements GpsView{
	
	public GpsViewImpl() {
		headerBackButton.setBackButton(true);
		headerPanel.setCenter("GPS");
		
		headerHomeButton.setText("Clear");
		headerHomeButton.setVisible(true);
		
		registryEvent();
		bind();
	}
	
	
	private HorizontalPanel gpsViewer( String longtitude,String latitude,String time){
		HorizontalPanel horizontalPanel = new HorizontalPanel();
		HTML time1 = new HTML(time);
		HTML gps = new HTML(longtitude +"E "+latitude+" N");
		
		horizontalPanel.setWidth("100%");
		time1.setHorizontalAlignment(HorizontalPanel.ALIGN_LEFT);
		gps.setHorizontalAlignment(HorizontalPanel.ALIGN_RIGHT);
		time1.setWidth("100%");
		gps.setWidth("100%");
		gps.getElement().getStyle().setColor("yellow");
		horizontalPanel.add(time1);
		horizontalPanel.add(gps);
		
		return horizontalPanel;
	}
	
	private void bind(){
		headerBackButton.addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				CaroOnline.clientFactory.getPlaceController().goTo(new GamePlace());
			}
		});
		
		headerHomeButton.addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				widgetList.clear();
			}
		});
	}
	
	
	private void registryEvent(){
		CaroOnline.clientFactory.getEventBus().addHandler(SendDataEvent.type, new SendDataEventHandle() {
			
			@Override
			public void onSendData(Position position) {
//				Window.alert(position.getTime() + GpsViewImpl.class.getName());
				
				widgetList.add(gpsViewer(position.getLongtitude(),position.getLatitude(), position.getTime()));
				scrollPanel.refresh();
				
				if(widgetList.getElement().getChildCount()==10){
					widgetList.clear();
				}
				
			}
		});
	}

}
