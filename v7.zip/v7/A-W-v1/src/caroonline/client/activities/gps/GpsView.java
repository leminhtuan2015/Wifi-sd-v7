package caroonline.client.activities.gps;

import caroonline.client.activities.basic.BasicView;

public interface GpsView extends BasicView{

}
