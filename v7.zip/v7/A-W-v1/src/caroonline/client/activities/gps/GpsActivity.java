package caroonline.client.activities.gps;

import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;

import caroonline.client.activities.ClientFactory;
import caroonline.client.activities.basic.BasicActivity;

public class GpsActivity extends BasicActivity{
	
	ClientFactory clientFactory;
	GpsView gpsView;

	public GpsActivity(ClientFactory clientFactory) {
		super(clientFactory);
		this.clientFactory = clientFactory;
		gpsView = clientFactory.getGpsView();
	}
	
	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		panel.setWidget(gpsView);
	}

	
}
