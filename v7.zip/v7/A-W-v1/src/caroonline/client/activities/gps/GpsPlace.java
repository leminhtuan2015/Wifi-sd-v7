package caroonline.client.activities.gps;

import com.google.gwt.place.shared.PlaceTokenizer;

import caroonline.client.activities.basic.BasicPlace;

public class GpsPlace extends BasicPlace{

    public GpsPlace() {
		token = "gps";
	}
	
	public static class Tokenizer implements PlaceTokenizer<GpsPlace>{

		@Override
		public GpsPlace getPlace(String token) {
			return new GpsPlace();
		}

		@Override
		public String getToken(GpsPlace place) {
			return place.getToken();
		}
		
	}
}
