package caroonline.client.activities;

import caroonline.client.activities.basic.BasicActivity;
import caroonline.client.activities.canvas.CanvasActivity;
import caroonline.client.activities.canvas.CanvasPlace;
import caroonline.client.activities.gallery.GalleryActivity;
import caroonline.client.activities.gallery.GalleryPlace;
import caroonline.client.activities.game.GameActivity;
import caroonline.client.activities.game.GamePlace;
import caroonline.client.activities.gps.GpsActivity;
import caroonline.client.activities.gps.GpsPlace;
import caroonline.client.activities.home.HomeActivity;
import caroonline.client.activities.home.HomePlace;

import com.google.gwt.activity.shared.Activity;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.place.shared.Place;

public class AppActivityMapper implements ActivityMapper {
	
	private final ClientFactory clientFactory ;
	private HomeActivity homeActivity;
	private GameActivity gameActivity;
	private CanvasActivity canvasActivity;
	private GpsActivity gpsActivity;
	private GalleryActivity galleryActivity;
	
	private static Place currentPlace;
	public static BasicActivity currentActivity ;
	
	public AppActivityMapper(ClientFactory clientFactory){
		this.clientFactory = clientFactory;
	}

	@Override
	public Activity getActivity(Place place) {
		currentPlace = place;
		
		if(place instanceof HomePlace){
			if(homeActivity == null){
				homeActivity = new HomeActivity(clientFactory);
			}
			currentActivity = homeActivity;
		}else if(place instanceof GamePlace){
			if(gameActivity==null){
				gameActivity = new GameActivity(clientFactory);
			}
			
			currentActivity = gameActivity;
		}else if(place instanceof CanvasPlace){
			if(canvasActivity==null){
				canvasActivity = new CanvasActivity(clientFactory);
			}
			
			currentActivity = canvasActivity;
		}else if(place instanceof GpsPlace){
			if(gpsActivity==null){
				gpsActivity = new GpsActivity(clientFactory);
			}
			
			currentActivity = gpsActivity;
		}else if(place instanceof GalleryPlace){
			if(galleryActivity==null){
				galleryActivity = new GalleryActivity(clientFactory);
			}
			
			currentActivity = galleryActivity;
		}
		
		if(currentActivity == null){
			if(homeActivity == null){
				homeActivity = new HomeActivity(clientFactory);
			}
			currentActivity = homeActivity;
		}
		
		
		return currentActivity;
	}
	
	public static Place getCurrentPlace() {
		return currentPlace;
	}

}
