package caroonline.client.activities;

import caroonline.client.activities.canvas.CanvasViewImpl;
import caroonline.client.activities.gallery.GalleryViewImpl;
import caroonline.client.activities.game.GameView;
import caroonline.client.activities.gps.GpsViewImpl;
import caroonline.client.activities.home.HomeView;
import caroonline.client.socket.SocketManager;

import com.google.gwt.place.shared.PlaceController;
import com.google.web.bindery.event.shared.EventBus;

public interface ClientFactory {
	
	public EventBus getEventBus();
	public PlaceController getPlaceController();
	public HomeView getHomeView();
	public GameView getGameView();
	public CanvasViewImpl getCanvasView();
	public GpsViewImpl getGpsView();
	public GalleryViewImpl getGalleryView();

}
