package caroonline.client.activities.home;


import com.google.gwt.user.client.ui.TextBox;
import com.googlecode.mgwt.ui.client.widget.Button;
import com.googlecode.mgwt.ui.client.widget.MTextBox;

import caroonline.client.activities.basic.BasicViewImpl;

public class HomeViewImpl extends BasicViewImpl implements HomeView {
	
	Button btnLogin = new Button("Login");
	MTextBox txtPassword = new MTextBox();
	
	public HomeViewImpl() {
		headerBackButton.setVisible(false);
		headerHomeButton.setVisible(false);
		headerHomeButton.setVisible(false);
		headerPanel.setCenter("Login");
		txtPassword.setPlaceHolder("Enter password");
		widgetList.add(txtPassword);
		widgetList.add(btnLogin);
	}
	
	
	public Button getBtnLogin() {
		return btnLogin;
	}

	@Override
	public MTextBox getTxtPassword() {
		return txtPassword;
	}
}

