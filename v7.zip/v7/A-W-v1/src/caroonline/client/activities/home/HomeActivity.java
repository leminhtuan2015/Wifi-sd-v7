package caroonline.client.activities.home;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;

import caroonline.client.CaroOnline;
import caroonline.client.activities.ClientFactory;
import caroonline.client.activities.basic.BasicActivity;
import caroonline.client.activities.game.GamePlace;
import caroonline.client.event.SendDataEvent;
import caroonline.client.event.SendDataEventHandle;
import caroonline.client.modal.Position;
import caroonline.shared.Data;

public class HomeActivity extends BasicActivity {
	
	private HomeView homeView;
	
	public HomeActivity(ClientFactory clientFactory) {
		super(clientFactory);
		homeView = clientFactory.getHomeView();
		bind();
	}
	
	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		panel.setWidget(homeView);
	}
	
	private void bind(){
		homeView.getBtnLogin().addTapHandler(new TapHandler() {
			@Override
			public void onTap(TapEvent event) {
				if(homeView.getTxtPassword().getText().isEmpty() || !homeView.getTxtPassword().getText().trim().equals("12345678")){
					Window.alert("please enter password");
					return;
				}
				clientFactory.getPlaceController().goTo(new GamePlace());
			}
		});
	}

}
