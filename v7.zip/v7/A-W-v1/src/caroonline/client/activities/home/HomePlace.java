package caroonline.client.activities.home;

import com.google.gwt.place.shared.PlaceTokenizer;
import caroonline.client.activities.basic.BasicPlace;

public class HomePlace extends BasicPlace{
	
	public HomePlace() {
		token = "Home";
	}
	
	public static class Tokenizer implements PlaceTokenizer<HomePlace>{

		@Override
		public HomePlace getPlace(String token) {
			return new HomePlace();
		}

		@Override
		public String getToken(HomePlace place) {
			return place.getToken();
		}
		
	}

}
