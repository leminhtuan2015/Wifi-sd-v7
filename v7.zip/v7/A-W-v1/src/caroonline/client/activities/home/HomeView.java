package caroonline.client.activities.home;


import com.google.gwt.user.client.ui.TextBox;
import com.googlecode.mgwt.ui.client.widget.Button;
import com.googlecode.mgwt.ui.client.widget.MTextBox;

import caroonline.client.activities.basic.BasicView;

public interface HomeView extends BasicView{
	public Button getBtnLogin();
	public MTextBox getTxtPassword();
}
