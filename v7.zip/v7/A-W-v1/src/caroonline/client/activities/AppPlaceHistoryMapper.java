package caroonline.client.activities;

import caroonline.client.activities.canvas.CanvasActivity;
import caroonline.client.activities.canvas.CanvasPlace;
import caroonline.client.activities.game.GamePlace;
import caroonline.client.activities.gps.GpsPlace;
import caroonline.client.activities.home.HomePlace;

import com.google.gwt.place.shared.PlaceHistoryMapper;
import com.google.gwt.place.shared.WithTokenizers;

@WithTokenizers({
	HomePlace.Tokenizer.class,
	GamePlace.Tokenizer.class,
	CanvasPlace.Tokenizer.class,
	GpsPlace.Tokenizer.class
})

public interface AppPlaceHistoryMapper extends PlaceHistoryMapper{
}
