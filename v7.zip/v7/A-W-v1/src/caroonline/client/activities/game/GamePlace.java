package caroonline.client.activities.game;

import caroonline.client.activities.basic.BasicPlace;
import com.google.gwt.place.shared.PlaceTokenizer;

public class GamePlace extends BasicPlace{
	
	public GamePlace() {
		token = "Game";
	}
	
	public static class Tokenizer implements PlaceTokenizer<GamePlace>{

		@Override
		public GamePlace getPlace(String token) {
			return new GamePlace();
		}

		@Override
		public String getToken(GamePlace place) {
			return place.getToken();
		}
		
	}
}
