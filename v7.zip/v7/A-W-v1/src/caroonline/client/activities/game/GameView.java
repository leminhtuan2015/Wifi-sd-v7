package caroonline.client.activities.game;


import java.util.List;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.googlecode.mgwt.ui.client.widget.Button;
import com.googlecode.mgwt.ui.client.widget.MTextBox;
import com.googlecode.mgwt.ui.client.widget.touch.TouchPanel;

import caroonline.client.activities.basic.BasicView;

public interface GameView extends BasicView {
	public Button getBtnImage();
	public Button getBtnLogout();
	public Button getBtnGPS();
	public Button getBtnBrows();
}
