package caroonline.client.activities.game;
import com.google.gwt.user.client.Window;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;
import com.googlecode.mgwt.ui.client.widget.Button;
import caroonline.client.CaroOnline;
import caroonline.client.activities.basic.BasicViewImpl;
import caroonline.client.activities.gallery.GalleryPlace;
import caroonline.client.activities.home.HomePlace;
public class GameViewImpl extends BasicViewImpl implements GameView{
	
	Button btnImage = new Button("Image");
	Button btnGPS = new Button("GPS");
	Button btnLogout = new Button("Logout");
	Button btnBrows = new Button("Gallery");
	
	public GameViewImpl() {
		headerPanel.setCenter("Image-GPS");
		headerBackButton.setVisible(false);
		headerHomeButton.setVisible(false);
//		DOM.setStyleAttribute(container.getElement(), "backgroundColor","#2062B8");
		widgetList.add(btnImage);
		widgetList.add(btnGPS);
		widgetList.add(btnBrows);
		widgetList.add(btnLogout);
		bind();
	}

	
	private void bind(){
		headerBackButton.addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				CaroOnline.clientFactory.getPlaceController().goTo(new HomePlace());
			}
		});
		
		btnLogout.addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				boolean lo = Window.confirm("Would you like to logout!");
				if(lo){
					CaroOnline.phoneGap.exitApp();
				}
			}
		});
		
		btnBrows.addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				CaroOnline.clientFactory.getPlaceController().goTo(new GalleryPlace());
			}
		});
		
		
	}


	@Override
	public Button getBtnImage() {
		return btnImage;
	}


	@Override
	public Button getBtnLogout() {
		return btnLogout;
	}


	@Override
	public Button getBtnGPS() {
		return btnGPS;
	}


	@Override
	public Button getBtnBrows() {
		return btnBrows;
	}

}
