package caroonline.client.activities.game;

import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;
import caroonline.client.activities.ClientFactory;
import caroonline.client.activities.basic.BasicActivity;
import caroonline.client.activities.canvas.CanvasPlace;
import caroonline.client.activities.gps.GpsPlace;
import caroonline.client.activities.home.HomePlace;
import caroonline.client.event.SendDataEvent;
import caroonline.shared.Data;

public class GameActivity extends BasicActivity{
	
	private GameView gameView;

	public GameActivity(ClientFactory clientFactory) {
		super(clientFactory);
		gameView = clientFactory.getGameView();
		bind();
	}
	
	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		panel.setWidget(gameView);
	}

	private void bind(){
		gameView.getBtnImage().addTapHandler(new TapHandler() {
			@Override
			public void onTap(TapEvent event) {
				clientFactory.getPlaceController().goTo(new CanvasPlace());
			}
		});
		
		gameView.getHomeButton().addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				clientFactory.getPlaceController().goTo(new HomePlace());
			}
		});
		
		gameView.getBtnGPS().addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				clientFactory.getPlaceController().goTo(new GpsPlace());
			}
		});
	}
	
}
