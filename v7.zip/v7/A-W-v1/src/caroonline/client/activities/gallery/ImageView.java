package caroonline.client.activities.gallery;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;

public class ImageView extends HorizontalPanel{
	
	String url = "";
	
	public ImageView(String url) {
		this.url = url;
		genImageView(url);
	}
	
	public HorizontalPanel genImageView(final String url){
		Image image = new Image(url);
		image.setSize("75px", "60px");
		image.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				Window.alert("URL :"+url);
			}
		});
		
		this.add(image);
		
		return this;
	}

}
