package caroonline.client.activities.gallery;

import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;
import com.googlecode.mgwt.ui.client.widget.ProgressBar;

import caroonline.client.CaroOnline;
import caroonline.client.activities.basic.BasicViewImpl;
import caroonline.client.activities.game.GamePlace;

public class GalleryViewImpl extends BasicViewImpl implements GalleryView{
	
	private ProgressBar progressBar = new ProgressBar();
	
	public GalleryViewImpl() {
		headerPanel.setCenter("Gallery");
		headerBackButton.setBackButton(true);
		headerHomeButton.setVisible(true);
		headerHomeButton.setText("Refresh");
		progressBar.setVisible(false);
		progressBar.setWidth("100%");
		widgetList.add(progressBar);
		bind();
	}
	
	private void bind(){
		headerBackButton.addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				CaroOnline.clientFactory.getPlaceController().goTo(new GamePlace());
			}
		});
	}

	@Override
	public ProgressBar progressBar() {
		return progressBar;
	}
	

}
