package caroonline.client.activities.gallery;

import caroonline.client.activities.basic.BasicPlace;

import com.google.gwt.place.shared.PlaceTokenizer;

public class GalleryPlace extends BasicPlace {
	
	public GalleryPlace() {
		token = "galery";
	}
	
	public static class Tokenizer implements PlaceTokenizer<GalleryPlace>{

		@Override
		public GalleryPlace getPlace(String token) {
			return new GalleryPlace();
		}

		@Override
		public String getToken(GalleryPlace place) {
			return place.getToken();
		}
		
	}

}
