package caroonline.client.activities.gallery;

import com.googlecode.mgwt.ui.client.widget.ProgressBar;

import caroonline.client.activities.basic.BasicView;

public interface GalleryView extends BasicView{
	ProgressBar progressBar();
}
