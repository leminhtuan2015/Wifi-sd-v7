package caroonline.client.activities.gallery;

import java.util.HashSet;
import java.util.Set;

import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.google.gwt.user.client.ui.Image;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;

import caroonline.client.CaroOnline;
import caroonline.client.activities.ClientFactory;
import caroonline.client.activities.basic.BasicActivity;
import caroonline.client.activities.canvas.CanvasActivity;
import caroonline.client.activities.canvas.CanvasPlace;
import caroonline.client.activities.canvas.CanvasViewImpl;

public class GalleryActivity extends BasicActivity {

	GalleryViewImpl galleryView;
	String length = "";
	String newestFolderName = "";
	Set<String> pathImages = new HashSet<String>();

	public GalleryActivity(ClientFactory clientFactory) {
		super(clientFactory);
		galleryView = clientFactory.getGalleryView();
		bind();
	}

	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		panel.setWidget(galleryView);
	}

	private void bind() {
		galleryView.getHomeButton().addTapHandler(new TapHandler() {

			@Override
			public void onTap(TapEvent event) {
				galleryView.progressBar().setVisible(true);
				if(newestFolderName.equals("")){
					getNewestFolderName(CanvasViewImpl.host);
				}else{
					refresh(CanvasViewImpl.localSave+newestFolderName);
				}
				
			}
		});
	}

	private native void getNewestFolderName(String host)/*-{
		//	alert(host+"");
		var app = this;
		$wnd.getFolderNames(
						host,
						function callback(newestFolderName) {
							//	  alert("newest folder:" + newestFolderName);
							app.@caroonline.client.activities.gallery.GalleryActivity::getNewestFolderNameSuccessCallback(Ljava/lang/String;)(newestFolderName);
						});
	}-*/;
	
	private void getNewestFolderNameSuccessCallback(String newestFoldername){
		if(newestFoldername.equals("null")){
			Window.alert("Please connect to WIDI sdcard");
			return;
		}
		this.newestFolderName = newestFoldername;
		refresh(CanvasViewImpl.localSave+newestFoldername);
	}

	private native void refresh(String host)/*-{
		var app = this;
		$wnd
				.getFileNamesGap(
						host,
						function callback(entries) {
							//		alert(entries.length);
							app.@caroonline.client.activities.gallery.GalleryActivity::getFileNamesGapSuccessCallback(Lcom/google/gwt/core/client/JavaScriptObject;)(entries);
						});
	}-*/;

	private void getFileNamesGapSuccessCallback(JavaScriptObject entries1) {

		galleryView.getWidgetList().clear();

		jsGetLength(entries1);
		int l = Integer.valueOf(length);
		// Window.alert("Length :" + l);

		for (int i = 0; i < l; i++) {
			String path = jsGetPath(entries1, i);
			pathImages.add(path);
		}

		for (String s : pathImages) {
			ImageView imageView = new ImageView(s);
			galleryView.getWidgetList().add(imageView);
		}

		galleryView.progressBar().setVisible(false);
		galleryView.getScrollPanel().refresh();
	}

	private native String jsGetLength(JavaScriptObject sc)/*-{
		var app = this;
		//	alert( sc.length +"xxx");
		//	alert( app.@caroonline.client.activities.gallery.GalleryViewImpl::length  +"yyy");

		app.@caroonline.client.activities.gallery.GalleryActivity::length = sc.length;
	}-*/;

	private native String jsGetPath(JavaScriptObject entries, int index)/*-{
		return entries[index].toURL();
	}-*/;
}
