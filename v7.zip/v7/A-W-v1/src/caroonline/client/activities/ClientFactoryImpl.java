package caroonline.client.activities;

import com.google.gwt.place.shared.Place;
import com.google.gwt.place.shared.PlaceController;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.SimpleEventBus;
import caroonline.client.activities.canvas.CanvasViewImpl;
import caroonline.client.activities.gallery.GalleryViewImpl;
import caroonline.client.activities.game.GameView;
import caroonline.client.activities.game.GameViewImpl;
import caroonline.client.activities.gps.GpsViewImpl;
import caroonline.client.activities.home.HomeView;
import caroonline.client.activities.home.HomeViewImpl;
import caroonline.client.socket.SocketManager;

public class ClientFactoryImpl implements ClientFactory{
	private EventBus eventBus;
	private PlaceController placeController;
	private SocketManager socketManager;
	private HomeView homeView;
	private GameView gameView;
	private CanvasViewImpl canvasView;
	private GpsViewImpl gpsViewImpl;
	private GalleryViewImpl galleryView;
	
	public ClientFactoryImpl() {
		eventBus = new SimpleEventBus();
		placeController = new PlaceController(eventBus);
	}

	@Override
	public EventBus getEventBus() {
		return eventBus;
	}

	@Override
	public PlaceController getPlaceController() {
		return placeController;
	}

	@Override
	public HomeView getHomeView() {
		if(homeView == null){
			homeView = new HomeViewImpl();
		}		
		return homeView;
	}

	@Override
	public GameView getGameView() {
		if(gameView==null){
			gameView = new GameViewImpl();
		}
		return gameView;
	}

	@Override
	public CanvasViewImpl getCanvasView() {
		if(canvasView==null){
			canvasView = new CanvasViewImpl();
		}
		return canvasView;
	}

	@Override
	public GpsViewImpl getGpsView() {
		if(gpsViewImpl==null){
			gpsViewImpl = new GpsViewImpl();
		}
		return gpsViewImpl;
	}

	@Override
	public GalleryViewImpl getGalleryView() {
		if(galleryView==null){
			galleryView = new GalleryViewImpl();
		}
		return galleryView;
	}

}
