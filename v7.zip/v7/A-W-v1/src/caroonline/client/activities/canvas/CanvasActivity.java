package caroonline.client.activities.canvas;

import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;

import caroonline.client.activities.ClientFactory;
import caroonline.client.activities.basic.BasicActivity;
import caroonline.client.activities.game.GamePlace;
import caroonline.client.activities.home.HomePlace;

public class CanvasActivity extends BasicActivity {
	
	private CanvasViewImpl canvasView;

	public CanvasActivity(ClientFactory clientFactory) {
		super(clientFactory);
		canvasView = clientFactory.getCanvasView();
		bind();
	}
	
	@Override
	public void start(AcceptsOneWidget panel, EventBus eventBus) {
		panel.setWidget(canvasView.asWidget());
	}
	
	private void bind(){
		canvasView.getBackButton().addTapHandler(new TapHandler() {
			
			@Override
			public void onTap(TapEvent event) {
				clientFactory.getPlaceController().goTo(new GamePlace());
			}
		});
		
	}

}
