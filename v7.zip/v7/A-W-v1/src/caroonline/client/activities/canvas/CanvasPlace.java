package caroonline.client.activities.canvas;

import com.google.gwt.place.shared.PlaceTokenizer;

import caroonline.client.activities.basic.BasicPlace;

public class CanvasPlace extends BasicPlace {
	
	public CanvasPlace() {
		token = "canvas";
	}
	
	public static class Tokenizer implements PlaceTokenizer<CanvasPlace>{

		@Override
		public CanvasPlace getPlace(String token) {
			return new CanvasPlace();
		}

		@Override
		public String getToken(CanvasPlace place) {
			return place.getToken();
		}
		
	}
}
