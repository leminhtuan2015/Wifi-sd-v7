package caroonline.client.activities.canvas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import caroonline.client.CaroOnline;
import caroonline.client.activities.basic.BasicViewImpl;
import caroonline.client.event.SendDataEvent;
import caroonline.client.modal.Position;

import com.google.gwt.canvas.client.Canvas;
import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.dom.client.ImageElement;
import com.google.gwt.event.dom.client.LoadEvent;
import com.google.gwt.event.dom.client.LoadHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.googlecode.mgwt.dom.client.event.tap.TapEvent;
import com.googlecode.mgwt.dom.client.event.tap.TapHandler;
import com.googlecode.mgwt.ui.client.widget.ProgressBar;

public class CanvasViewImpl extends BasicViewImpl implements CanvasView{
	
	public final static String host = "http://192.168.11.254/sd/DCIM/";
	public final static String localSave = "/mnt/sdcard/WIFISD/";
	
	private Canvas canvas = Canvas.createIfSupported();
	private Context2d context ;
	
	public static String newestFolderName = "";
	private String newestImageName = "";
	private String timeCaptureString = "";
	
	private String longtitudeString = "";
	private String latitudeString = "";
	
	private Map<String, String> gpsMapper = new HashMap<String, String>();
	
	private Timer timerGetNewestImage ;
	private Timer timerUpdateGPS;
	
	ProgressBar progressBar = new ProgressBar();
	HTML longitude = new HTML("E");
	HTML latitude = new HTML("N");
	HTML timeCaptute = new HTML("Time :");
	
	VerticalPanel loadImageWifiCard = new VerticalPanel();
	
	public CanvasViewImpl() {		
		headerBackButton.setBackButton(true);
		headerPanel.setCenter("Current image");
		headerHomeButton.setText("GPS");
		headerHomeButton.setVisible(false);
		
//		DOM.setStyleAttribute(containerImageRoot.getElement(), "backgroundColor","gray");

		progressBar.setVisible(true);
//		progressBar.getElement().getStyle().setBackgroundColor("red");
		progressBar.setWidth("100%");
		
		widgetList.add(progressBar);
		widgetList.add(longitude);
		widgetList.add(latitude);
		widgetList.add(timeCaptute);
		
		loadImageWifiCard.setWidth("100%");
		loadImageWifiCard.setHorizontalAlignment(HorizontalPanel.ALIGN_CENTER);
		widgetList.add(loadImageWifiCard);
		
//		bind();		
		autoRun();
//		saveByCanvas();
	}
	
//	private native void storeImageToDevice(String base64String,String fileName,String location)/*-{
//		$wnd.convertBase64(base64String,fileName,location);
//	}-*/;
		
	private native void getGPS()/*-{
		var app = this;
		$wnd.getGPS(function(position) {
//						alert("Latitude:" + position.coords.latitude +"/ "+ "Longitude:" + position.coords.longitude);
					    app.@caroonline.client.activities.canvas.CanvasViewImpl::getGPSSuccessCallback(Ljava/lang/String;Ljava/lang/String;)(position.coords.longitude, position.coords.latitude);
					},
					function(error) {
						alert('GPS check your connection! :code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
						app.@caroonline.client.activities.canvas.CanvasViewImpl::getGPSFailCallback()();
					}
					);
	}-*/;
	
	private void getGPSSuccessCallback(String longitude,String latitude){
		Window.alert("get GPS success");
		this.longtitudeString = longitude;
		this.latitudeString = latitude;
		this.longitude.setHTML(longitude+"E");
		this.latitude.setHTML(latitude+"N");
		
//		getImageFromWifiCard("/WIFISD/DCIM/203_0701/IMG_0058.JPG");
//		getImageFromWifiCard("/mnt/sdcard/DCIM/WIFISD/IMG_0049.JPG");
//		getImageFromWifiCard("http://images6.fanpop.com/image/photos/32300000/Iron-Man-3-iron-man-32378886-1063-1375.jpg");
//		getImageFromWifiCard("http://192.168.11.254/sd/DCIM/" , "203_0701/IMG_0021.JPG");
	}
	
	private void getGPSFailCallback(){
		Window.alert("get GPS fail");
	}

	@Override
	public HTML getLongitude() {
		return longitude;
	}

	@Override
	public HTML getLatitude() {
		return latitude;
	}
	
	private void bind(){
		headerHomeButton.addTapHandler(new TapHandler() {
			@Override
			public void onTap(TapEvent event) {
				getGPS();
			}
		});
	}//end bind
	
	private native void getNewestImageName(String host)/*-{
//		alert(host+"");
		var app = this;
		 $wnd.getFileNames(host,function callback(newestImageName ,timeCapture){
//			alert("newest File :" + newestImageName);
			app.@caroonline.client.activities.canvas.CanvasViewImpl::getNewestImageNameSuccessCallback(Ljava/lang/String;Ljava/lang/String;)(newestImageName,timeCapture);
		});
	}-*/;
	
	private native void getNewestFolderName(String host)/*-{
//		alert(host+"");
	    var app = this;
	    $wnd.getFolderNames(host,function callback(newestFolderName){
//		  alert("newest folder:" + newestFolderName);
		  app.@caroonline.client.activities.canvas.CanvasViewImpl::getNewestFolderNameSuccessCallback(Ljava/lang/String;)(newestFolderName);
	    });
    }-*/;
	
	private void getNewestImageNameSuccessCallback(String newestImageName,String timeCapture){
//		Window.alert("newest image :" + newestImageName + ":"+ timeCapture);
		
		if(newestImageName.equals("null")){
//			Window.alert("Please connection to device ");
			timerGetNewestImage.schedule(1000);
			return;
		}
		if(this.newestImageName.equals(newestImageName)){
			timerGetNewestImage.schedule(1000);	
			return;
		}else{
			this.newestImageName = newestImageName;
			this.timeCaptureString = timeCapture;
			this.headerPanel.setCenter(newestImageName);
			this.timeCaptute.setHTML("Time :"+convertTimeCapture(timeCapture));
			
			String gpsWhenCapture = matchingGpsWithTimeCapture();
			copyImageToLocal(this.host+this.newestFolderName+this.newestImageName, this.newestImageName,this.newestFolderName,this.localSave,gpsWhenCapture,convertTimeCapture(timeCapture));
			
		}
	}
	
	private String matchingGpsWithTimeCapture(){
		String gps = gpsMapper.get(convertTimeCapture(timeCaptureString));
		if(gps==null || gps.equals("")){
			if(!longtitudeString.equals("")){
				gps = convertGPS(longtitudeString)+":"+convertGPS(latitudeString);
			}else{
				gps="E:N";
			}
		}
		return gps;
	}
	
	private native void copyImageToLocal(String url,String filename,String folderName,String location,String gps,String time)/*-{
		var app = this;
		$wnd.getImageFromSD(url,filename,folderName,location,gps,time,function(status){ 
		  app.@caroonline.client.activities.canvas.CanvasViewImpl::copyImageToLocalSuccessCallback(Ljava/lang/String;)(status);
		});
	}-*/;
	
	private void copyImageToLocalSuccessCallback(String status){
		if(status.equals("success")){
//			Window.alert("save ok");
			showNewestImage();
		}else{
			Window.alert("save fail");
		}
		
		timerGetNewestImage.schedule(1);
	}
	

	private void saveByCanvas(){
	    context = canvas.getContext2d();
		final Image image = new Image("file:///android_asset/www/images/IMG_0381.JPG");
		loadImageWifiCard.clear();
		loadImageWifiCard.add(image);
		image.addLoadHandler(new LoadHandler() {
			@Override
			public void onLoad(LoadEvent event) {
				loadImageWifiCard.clear();
				canvas.setCoordinateSpaceWidth(image.getWidth());
				canvas.setCoordinateSpaceHeight(image.getHeight());
				ImageElement imageElement = ImageElement.as(image.getElement());
				context.drawImage(imageElement, 0, 0, image.getWidth(),image.getHeight());
				String imageData = canvas.toDataUrl("image/jpg");
//				Window.alert(imageData);
				Image image1 = new Image(imageData);
				image1.setSize("320px", "250px");
				loadImageWifiCard.add(image1);
				storeOnLocal(imageData);
			}
		});

	}
	
	private native void storeOnLocal(String imageData)/*-{
		var app = this;
		$wnd.convertBase64(imageData,'','',function calback(status){
//			alert(status+'');
			app.@caroonline.client.activities.canvas.CanvasViewImpl::storeOnLocalSuccess(Ljava/lang/String;)(status);
			
		});
    }-*/;
	
	private void storeOnLocalSuccess(String status){
		addExif();
	}
	
	private native void addExif()/*-{
	var app = this;
	$wnd.exifImage(function calback(status){
//		alert(status+'');
		app.@caroonline.client.activities.canvas.CanvasViewImpl::addExifSuccess(Ljava/lang/String;)(status);
		
	});
}-*/;
	
	private void addExifSuccess(String status){
		Window.alert("exift ok");
	}
	
	private void showNewestImage(){
		Image image = new Image(host+newestFolderName+newestImageName);
		image.setSize("320px", "250px");
		loadImageWifiCard.clear();
		loadImageWifiCard.add(image);
		scrollPanel.refresh();
		
	}
	
	private void getNewestFolderNameSuccessCallback(String newestFolderName){
		if(newestFolderName.equals("null")){
			timerGetNewestImage.schedule(1000);
			return;
		}else{
			this.newestFolderName = newestFolderName;
			getNewestImageName(this.host+this.newestFolderName);
		}
	}
	
	private void autoRun(){
		timerGetNewestImage = new Timer() {
			@Override
			public void run() {
				if(newestFolderName.equals("")){
					getNewestFolderName(host);
				}else{
					getNewestImageName(host+newestFolderName);
				}
			}
		};
		
		timerUpdateGPS = new Timer() {
			
			@Override
			public void run() {
				updateGPS();
			}
		};
		
		timerUpdateGPS.schedule(1);
		timerGetNewestImage.schedule(1000);
		
	} 

	private native void updateGPS()/*-{
	var app = this;
	$wnd.getGPS(function(position) {
//					alert("Latitude:" + position.coords.latitude +"/ "+ "Longitude:" + position.coords.longitude);
				    app.@caroonline.client.activities.canvas.CanvasViewImpl::updateGPSSuccessCallback(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)(position.coords.longitude, position.coords.latitude,new Date(position.timestamp)+"");
				},
				function(error) {
					alert('GPS check your connection! :code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
					app.@caroonline.client.activities.canvas.CanvasViewImpl::updateGPSFailCallback()();
				}
				);
}-*/;
	
	private void updateGPSSuccessCallback(String longtitude,String latitude,String timestamp){
//		Window.alert("update GPS success");
		timerUpdateGPS.schedule(1);
		this.longtitudeString = longtitude;
		this.latitudeString = latitude;
		this.longitude.setHTML(longtitude+"E");
		this.latitude.setHTML(latitude+"N");
		fireEvent(longtitude,latitude,timestamp);
	}
	
	private void updateGPSFailCallback(){
		timerUpdateGPS.schedule(1);
	}
	
	private void fireEvent(String longtitude,String latitude,String timestamp){
		String longtitude1 = convertGPS(longtitude);
		String latitude1 = convertGPS(latitude);
		String timestamp1 = convertTimeGPS(timestamp);
		
		if(gpsMapper.size()==60){
			gpsMapper.clear();
		}
		gpsMapper.put(timestamp1, longtitude1+":"+latitude1);
		
		Position position = new Position(longtitude1,latitude1,timestamp1);
		CaroOnline.clientFactory.getEventBus().fireEvent(new SendDataEvent(position));
	}
	
	private String convertTimeGPS(String timestamp){
//		Window.alert("gps:"+timestamp);
		String times[] = timestamp.split(" ");
		String y = times[3].trim();
		String m = getMonth(times[1].trim());
		String d = times[2].trim();
		String h = times[4].trim();
		String time = y+"."+m+"."+d+" "+h;
		return time;
	}
	
	private String convertTimeCapture(String timestamp){
//		Window.alert("img:"+timestamp);
		String times[] = timestamp.split(" ");
		String y = times[4].trim();
		String m = getMonth(times[1].trim());
		String d = times[2].trim();
		String h = times[3].trim();
		
		String time = y+"."+m+"."+d+" "+h;
		return time;
	}
	
	private String getMonth(String month){
		String month1 = "";
		if(month.equals("Jan")){
			month1 = "01";
		}else if(month.equals("Feb")){
			month1 = "02";
		}else if(month.equals("Mar")){
			month1 = "03";
		}else if(month.equals("Apr")){
			month1 = "04";
		}else if(month.equals("May")){
			month1 = "05";
		}else if(month.equals("Jun")){
			month1 = "06";
		}else if(month.equals("Jul")){
			month1 = "07";
		}else if(month.equals("Aug")){
			month1 = "08";
		}else if(month.equals("Sep")){
			month1 = "09";
		}else if(month.equals("Oct")){
			month1 = "10";
		}else if(month.equals("Nov")){
			month1 = "11";
		}else if(month.equals("Dec")){
			month1 = "12";
		}
		
		return month1;
		
	}
	
	private String convertGPS(String l){
		String D="";
		String M="";
		String S="";
		
		int d = Integer.valueOf(l);
		double dd = Double.valueOf(l);
		double tp = dd-d;
		
		
		D = String.valueOf(d);
		M = String.valueOf((int)(tp*60));
		
		int m = (int)(tp*60);
		
	    S = String.valueOf( (int)(((tp*60)-m)*60) );
		return D+"*"+M+"'"+S+"''";
	}
	
	private void uploadToDropbox(){
	}

	@Override
	public HTML getTimeCapture() {
		return timeCaptute;
	}

	@Override
	public Timer timerGetNewestImage() {
		return timerGetNewestImage;
	}

	@Override
	public Timer timerUpdateGPS() {
		return timerUpdateGPS;
	}
	
}
