package caroonline.client.activities.canvas;

import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.HTML;
import caroonline.client.activities.basic.BasicView;

public interface CanvasView extends BasicView{

	HTML getLongitude();
	HTML getLatitude();
	HTML getTimeCapture();
	Timer timerGetNewestImage();
	Timer timerUpdateGPS();
}
