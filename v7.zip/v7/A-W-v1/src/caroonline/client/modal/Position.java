package caroonline.client.modal;

public class Position {
	String longtitude;
	String latitude;
	String time;
	
	public Position() {
	}
	
	public Position(String longtitude,String latitude,String time){
		this.latitude = latitude;
		this.longtitude = longtitude;
		this.time = time;
	}
	
	public String getLongtitude() {
		return longtitude;
	}
	public void setLongtitude(String longtitude) {
		this.longtitude = longtitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	

}
