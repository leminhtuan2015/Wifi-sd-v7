package com.x.function;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

import org.apache.sanselan.Sanselan;
import org.apache.sanselan.common.IImageMetadata;
import org.apache.sanselan.formats.jpeg.JpegImageMetadata;
import org.apache.sanselan.formats.jpeg.exifRewrite.ExifRewriter;
import org.apache.sanselan.formats.tiff.TiffImageMetadata;
import org.apache.sanselan.formats.tiff.write.TiffOutputSet;

import android.R.bool;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Environment;
import android.util.Log;

public class CanvasImage {

	public CanvasImage() {
	}

	public void exChangeImage(String url, String time,String gps,
			String locationSave, String imagename) {
		Log.d("Path :", url);
		Log.d("Text :", time + gps);
		Log.d("locationSave :", locationSave);
		Log.d("imagename :", imagename);

		File folder = new File(locationSave);
		folder.mkdirs();
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(new File(
					folder, imagename));
			Bitmap bitmap = decodeUrl(url);
			bitmap = convertToMutable(bitmap);
			boolean s = bitmap.isMutable();
			Log.d("Bitmap isMutable :", "" + s);
			Canvas canvas = new Canvas(bitmap);
			Paint paint = new Paint();
			paint.setColor(Color.WHITE); // Text Color
			int textSize = bitmap.getWidth()/50;
			String[] gps1 = gps.split(":");
			gps = gps1[0] + "N"+"   " + gps1[1]+"E";
			paint.setTextSize(textSize);
			canvas.drawText(time, 10, textSize, paint);
			canvas.drawText(gps, (bitmap.getWidth()-(bitmap.getWidth()/4)), textSize, paint);
			canvas.save();
			bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
			fileOutputStream.flush();
			fileOutputStream.close();
			Log.d("INSERT GPS", "Success");
		} catch (Exception e) {
			Log.d("Insert gps err :", e.getMessage());
		}
	}
	
	private Bitmap decodeUrl(String url ){
		return BitmapFactory.decodeFile(url);
	}

	public Bitmap convertToMutable(Bitmap imgIn) {
		try {
			// this is the file going to use temporally to save the bytes.
			// This file will not be a image, it will store the raw image data.
			File file = new File(Environment.getExternalStorageDirectory()
					+ File.separator + "temp.tmp");

			// Open an RandomAccessFile
			// Make sure you have added uses-permission
			// android:name="android.permission.WRITE_EXTERNAL_STORAGE"
			// into AndroidManifest.xml file
			RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");

			// get the width and height of the source bitmap.
			int width = imgIn.getWidth();
			int height = imgIn.getHeight();
			Bitmap.Config type = imgIn.getConfig();

			// Copy the byte to the file
			// Assume source bitmap loaded using options.inPreferredConfig =
			// Config.ARGB_8888;
			FileChannel channel = randomAccessFile.getChannel();
			MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_WRITE,
					0, imgIn.getRowBytes() * height);
			imgIn.copyPixelsToBuffer(map);
			// recycle the source bitmap, this will be no longer used.
			imgIn.recycle();
			System.gc();// try to force the bytes from the imgIn to be released

			// Create a new bitmap to load the bitmap again. Probably the memory
			// will be available.
			imgIn = Bitmap.createBitmap(width, height, type);
			map.position(0);
			// load it back from temporary
			imgIn.copyPixelsFromBuffer(map);
			// close the temporary file and channel , then delete that also
			channel.close();
			randomAccessFile.close();

			// delete the temp file
			file.delete();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return imgIn;
	}

}
