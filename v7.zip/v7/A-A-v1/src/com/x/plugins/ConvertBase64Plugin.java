package com.x.plugins;

import java.io.File;
import java.io.FileOutputStream;
import org.apache.cordova.api.CallbackContext;
import org.apache.cordova.api.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import android.util.Base64;
import android.util.Log;

public class ConvertBase64Plugin extends CordovaPlugin{
	
	private String base64Data = "";
	private String fileName = "";
	private String location = "";
	
	@Override
	public boolean execute(String action, JSONArray args,
			CallbackContext callbackContext) throws JSONException {
		
		this.base64Data = args.getString(0);
		this.fileName = args.getString(1);
		this.location = args.getString(2);
		
		base64Data = base64Data.replace("data:image/jpg;base64,", "");
		base64Data = base64Data.replace("data:image/png;base64,", "");
		Log.d("xxxxxx", base64Data);
		byte[] bais = convertBase64ToBais(base64Data);
		storeImageToSd(bais);
		callbackContext.success("store ok");
		return true;
	}
	
	
	public byte[] convertBase64ToBais(String base64String){
		byte[] decode = Base64.decode(base64String, Base64.DEFAULT);
		return decode;
	}
	
	private void storeImageToSd(byte[] decode){
		try {
			File folder = new File("/mnt/sdcard/WIFISD/TEST/");
			folder.mkdirs();
			
			File file = new File(folder,"test.jpg" );
			file.createNewFile();
			
			FileOutputStream fileOutputStream = new FileOutputStream(file);
			fileOutputStream.write(decode);
			fileOutputStream.flush();
			fileOutputStream.close();
			Log.d("status", "Success export image");
			
		} catch (Exception e) {
			Log.d("",""+e);
		}
	}

}
