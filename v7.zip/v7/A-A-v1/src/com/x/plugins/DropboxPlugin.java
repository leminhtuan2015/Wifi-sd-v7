package com.x.plugins;


public class DropboxPlugin {
//	
//	DbxAccountManager dbxAccountManager;
//	DropboxAPI dropboxAPI;
//	
//	public Dropbox() {
//		dbxAccountManager = DbxAccountManager.getInstance(null, "APP_KEY", "APP_SECRET");
//		dbxAccountManager.startLink(activity, callbackRequestCode)
//		
//	}
	

}
