package com.x.plugins;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.apache.cordova.DroidGap;
import org.apache.cordova.GPSListener;
import org.apache.cordova.api.CallbackContext;
import org.apache.cordova.api.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

import com.x.function.CanvasImage;

import android.R.bool;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.GpsStatus;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.util.Log;
import android.webkit.GeolocationPermissions;

public class GetImageFromSDPlugin extends CordovaPlugin{
	
	private String url = "";
	private String fileName = "";
	private String folderName = "";
	private String location = "";
	private String gps = "";
	private String time = "";
	private byte[] bais ;
	
	private String pathFolderGPS = "";
	private String pathFolderGPSEXIF = "";
	
	private CallbackContext callbackContext;
	 
	@Override
	public boolean execute(String action, JSONArray args,
			CallbackContext callbackContext) throws JSONException {
		
		this.callbackContext = callbackContext;
		
		this.url = args.getString(0);
		this.fileName = args.getString(1);
		this.folderName = args.getString(2); 
		this.location = args.getString(3);
		this.gps = args.getString(4);
		this.time = args.getString(5);
		
		pathFolderGPS = location+folderName.replace("/", "_GPS/");
		pathFolderGPSEXIF = location+folderName.replace("/", "_GPS_EXIF/");
		
		Log.d("url :", url);
		Log.d("file name :", fileName);
		Log.d("folder name :", folderName);
		Log.d("location :", location);
		Log.d("gps :", gps);
		Log.d("time :", time);
		Log.d("Path gps :", pathFolderGPS);
		Log.d("Path gps_exif:", pathFolderGPSEXIF);
		
		AsyncTask<String, Void, String> asyncTask = new AsyncTask<String, Void, String>(){
			@Override
			protected String doInBackground(String... params) {
				runBackground(GetImageFromSDPlugin.this.callbackContext);
				return "";
			}
			
			@Override
			protected void onPostExecute(String result) {
				System.gc();
			}
		};
		
		asyncTask.execute(null);

		return true;
	}
	
	private void runBackground(CallbackContext callbackContext){
		boolean storeOk = copyImageToSD();
		
		if(storeOk){
			callbackContext.success("ok");
			Log.d("Store :", "Success");
			insertGPS();
			insertMetadataEXIF();
		}else{
			callbackContext.error("fail");
			Log.d("Store :", "Fail");
		}
	}
	
	public boolean copyImageToSD(){
	    bais = getImageFromUrl(url);
		Log.d("Image size :",bais.length+"");
		return storeImageToLocal(bais);
	}
	
	private boolean storeImageToLocal(byte[] bais){
		try {
			File folder = new File(location+folderName);
			folder.mkdirs();
			
			File file = new File(folder,fileName);
			file.createNewFile();
			
			FileOutputStream fileOutputStream = new FileOutputStream(file);
		    fileOutputStream.write(bais);
		    fileOutputStream.flush();
		    fileOutputStream.close();
		    
		    return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	
	public byte[] getImageFromPath(String urlStr){
		ByteArrayOutputStream bais = new ByteArrayOutputStream();
		 byte[] byteChunk = new byte[4096]; // Or whatever size you want to read in at a time.
		try {
			InputStream is = null;
			try {
				is = new FileInputStream(urlStr);
			  int n;
			  while ( (n = is.read(byteChunk)) > 0 ) {
			    bais.write(byteChunk, 0, n);
			  }
			}
			catch (IOException e) {
			  Log.d("Failed while reading bytes from","");
			  e.printStackTrace ();
			}
			finally {
			  if (is != null) { is.close(); }
			}
		} catch (Exception e) {
		}
		return bais.toByteArray();
	}
	
	private byte[] getImageFromUrl(String urlStr){
		ByteArrayOutputStream bais = new ByteArrayOutputStream();
		 byte[] byteChunk = new byte[4096]; // Or whatever size you want to read in at a time.
		try {
			URL url = new URL(urlStr);
			InputStream is = null;
			try {
			  is = url.openStream ();
			  int n;
			  while ( (n = is.read(byteChunk)) > 0 ) {
			    bais.write(byteChunk, 0, n);
			  }
			}
			catch (IOException e) {
			  System.err.printf ("Failed while reading bytes from %s: %s", url.toExternalForm(), e.getMessage());
			  e.printStackTrace ();
			}
			finally {
			  if (is != null) { is.close(); }
			}
		} catch (Exception e) {
		}
		return bais.toByteArray();
	}
	
	private void insertMetadataEXIF(){
		Log.d("EXIF BEGIN", "Exif");
		ExifImagePlugin exifImage = new ExifImagePlugin();
		byte[] imageData_gps = getImageFromPath(pathFolderGPS+fileName);
		byte[] data = exifImage.addMetadata(imageData_gps,location+folderName+fileName);
		
		File file = new File(pathFolderGPSEXIF);
		file.mkdirs();
		
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(new File(file,fileName));
			fileOutputStream.write(data);
			fileOutputStream.flush();
			fileOutputStream.close();
			
			exifImage = new ExifImagePlugin(pathFolderGPSEXIF+fileName);
			exifImage.addAttribute(ExifInterface.TAG_MAKE, "TuanMinhLe");
			exifImage.addAttribute(ExifInterface.TAG_GPS_LONGITUDE, "21/1,18/1,29034/625");
			exifImage.addAttribute(ExifInterface.TAG_GPS_LATITUDE, "21/1,18/1,29034/625");
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	private void insertGPS(){
		Log.d("GPS", gps);
		CanvasImage canvasImage = new CanvasImage();
		canvasImage.exChangeImage(location+folderName+fileName,time,gps, pathFolderGPS,fileName);
	}

}
