package com.x.plugins;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Hashtable;

import org.apache.cordova.DroidGap;
import org.apache.cordova.api.CallbackContext;
import org.apache.cordova.api.CordovaPlugin;
import org.apache.sanselan.Sanselan;
import org.apache.sanselan.common.IImageMetadata;
import org.apache.sanselan.formats.jpeg.JpegImageMetadata;
import org.apache.sanselan.formats.jpeg.exifRewrite.ExifRewriter;
import org.apache.sanselan.formats.tiff.TiffImageMetadata;
import org.apache.sanselan.formats.tiff.write.TiffOutputSet;
import org.json.JSONArray;
import org.json.JSONException;
import org.w3c.tools.jpeg.Exif;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.media.ExifInterface;
import android.util.Log;

public class ExifImagePlugin extends CordovaPlugin{

	ExifInterface exifInterface;
	
	public ExifImagePlugin(String url) {
		try {
			 exifInterface = new ExifInterface(url);
		} catch (Exception e) {
			Log.d("EXIF err", e.getMessage());
		}
	}
	
	public ExifImagePlugin() {
	}
	
	@Override
	public boolean execute(String action, JSONArray args,
			CallbackContext callbackContext) throws JSONException {
		
		Log.d("exift ", "exif function");
		return true;
	}
	
	public void addAttribute(String attrName,String value){
		try {
			exifInterface.setAttribute(attrName, value);
			exifInterface.saveAttributes();
		} catch (Exception e) {
			Log.d("", "error");
		}
	}
	
	public String getAttribute(String attrName){
		return exifInterface.getAttribute(attrName);
	}
	
	
	public byte[] addMetadata(byte[] dataImage,String imageNative){
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		TiffOutputSet outputSet = null;
		try {
			// filepath is the path to your image file stored in SD card (which contains exif info)
			IImageMetadata metadata = Sanselan.getMetadata(new File(imageNative)); 
			JpegImageMetadata jpegMetadata = (JpegImageMetadata) metadata;
			if (null != jpegMetadata)
			{
			    TiffImageMetadata exif = jpegMetadata.getExif();
			    if (null != exif)
			    {
			        outputSet = exif.getOutputSet();
			    }
			}
			if (null != outputSet)
			{
			    ExifRewriter ER = new ExifRewriter();
			    ER.updateExifMetadataLossless(dataImage, bos, outputSet);
			    dataImage = bos.toByteArray(); //Update you Byte array, Now it contains exif information!
			}
			
			Log.d("METADATA ADD ", " ok" );
			return dataImage;
		} catch (Exception e) {
			Log.d("METADATA err ", " err" + e);
			return null;
			
		}

	}
}
