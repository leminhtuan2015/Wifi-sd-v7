var newestFolderName = '';
var indexMax = 0;

function getFolderNames(host, callback) {
	// alert("Detecting newest image ...|" + host + folder);
	$.ajax({
		url : host + "",
		cache : false,
		success : function(data) {
			$(data).find("a:contains(/)").each(function(index, domEle) {
				indexMax = index;
			});

			$(data).find("a").each(function(index, domEle) {
				// alert($(this).html()+"");
				if (index == indexMax) {
					newestFolderName = $(this).html();
					// alert(timeCapture+'')
					callback(newestFolderName);
				}

			});

		},// end success

		error : function() {
			callback('null');
		}

	});
}
