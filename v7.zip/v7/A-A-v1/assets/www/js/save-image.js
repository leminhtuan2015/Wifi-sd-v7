function save() {
	window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
}

function gotFS(fileSystem) {
	// Default into sdcard
	alert("1");
	fileSystem.root.getFile("aaaaa.txt", {
		create : true,
		exclusive : false
	}, gotFileEntry, fail);
}

function gotFileEntry(fileEntry) {
	alert("2");
	fileEntry.createWriter(gotFileWriter, fail);
}

function gotFileWriter(writer) {
	alert("3");
	writer.write("some sample text");
}

function fail(error) {
	alert("4");
	console.log(error.code);
}
