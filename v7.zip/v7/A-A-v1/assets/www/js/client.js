var socketio ;
var userId ;

function openSocketToServer(id,callBack){
    //Client open socket to server
    socketio = io.connect("http://localhost:1337");
    registrySocketReceiveMessage(id,callBack);
}

function registrySocketReceiveMessage(id,callBack){
	// execute when socket receive message
	userId = id; 
    socketio.on(id, function(data) {
    	callBack(data['fromUser'],data['message']);
//      alert( id + " receive data :" + data['message'] + " from : " + data['fromUser']);
    });
}

function sendMessage(to,content) {
	//Use socket send message 
    socketio.emit("TUAN.SOCKET.SERVER", { from : userId, sendTo : to , message: content});
}