function getGPS(onSuccess,onError) {
//	alert("checking...");
	navigator.geolocation.getCurrentPosition(onSuccess, onError,{ enableHighAccuracy: true });
}
//function onSuccess(position) {
//	alert("success");
//	alert("Latitude:" + position.coords.latitude +"/ "+ "Longitude:" + position.coords.longitude);
//}
//
//function onError(error) {
//	alert('code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
//}