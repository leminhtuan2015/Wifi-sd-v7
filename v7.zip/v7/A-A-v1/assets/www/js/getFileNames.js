var newestImageName = '';
var timeCapture = '';
var indexMax = 0;

function getFileNames(host,callback){
//	alert("Detecting newest image ...|" + host + folder);
	$.ajax({
		  url: host+"",
		  cache : false,
		  success: function(data){ 
//			 alert(data);
		     
//		     $(data).find("td:contains(2013)").each(function(){
//		    	 //Alert date 
////		    	 alert("date : " + $(this).html());
//		     });
		     
		     $(data).find("a:contains(.JPG)").each(function ( index, domEle) {
		    	 indexMax = index;
		     });
		     
//		     alert(indexMax+" max");
		     
		     $(data).find("a:contains(.JPG)").each(function(index, domEle){
		    	 if(index==indexMax){
//		    		 alert("image : " + $(this).attr("href"));
		    		 newestImageName = $(this).attr("href");
//		    		 callback(newestImageName,timeCapture);
		    	 }
//		    	 location.reload();
		     });
		     
		     $(data).find("td:contains(:)").each(function(index, domEle){
//		    	 alert($(this).html()+"");
		    	 if(index==indexMax){
		    		 timeCapture = $(this).html();
//		    		 alert(timeCapture+'')
		    		 callback(newestImageName,timeCapture);
		    	 }
		    	 
		     });
		     
		     
		  },//end success
	    
		  error : function(){
			  callback('null');
		  }
		  
		});
}


