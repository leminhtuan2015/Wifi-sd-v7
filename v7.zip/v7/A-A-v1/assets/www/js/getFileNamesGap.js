
var host1 = '';
var callback1;

function getFileNamesGap(locationParam,callback){
	host1 = locationParam;
	callback1 = callback;
	window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onFileSystemSuccess, fail);	
}

function onFileSystemSuccess(fileSystem) {
    fileSystem.root.getDirectory(host1, {create: false, exclusive: false}, getDirSuccess, fail);
}

function getDirSuccess(dirEntry) {
    // Get a directory reader
    var directoryReader = dirEntry.createReader();
    // Get a list of all the entries in the directory
    directoryReader.readEntries(readerSuccess,fail);
}

function fail(){
	alert('Not found folder (Err at : getFileNamesGap.js)');
}

function readerSuccess(entries) {
	callback1(entries);
	
//	alert(entries.length);
//    var i;
//    for (i=0; i<entries.length; i++) {
//    	alert(entries[i].name);
//    	alert(entries[i].toURL());
////    	alert(entries[i].remove());
//    }
}

function removeFile(entry){
	entry.remove();
}