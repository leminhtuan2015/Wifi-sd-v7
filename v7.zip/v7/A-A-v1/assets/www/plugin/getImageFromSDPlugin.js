function getImageFromSD(url,fileName,folderName,locationSave,gps,time,callback) {
	cordova.exec(
		function(winParam) {callback('success');},
		function(error) {callback('fail');}, 
	"GetImageFromSDPlugin",
    "convertaction",
    [url,fileName,folderName,locationSave,gps,time]);
}