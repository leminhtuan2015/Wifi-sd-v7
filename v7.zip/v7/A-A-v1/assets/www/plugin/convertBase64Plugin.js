function convertBase64(base64String,filename,location,calback) {
	cordova.exec(
		function(winParam) {calback("ok");},
		function(error) {alert(error);}, 
	"ConvertBase64Plugin",
    "convertaction",
    [base64String,filename,location]);
}