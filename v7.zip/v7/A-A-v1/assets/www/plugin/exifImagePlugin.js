function exifImage(calback) {
	cordova.exec(
		function(winParam) {calback('0k');},
		function(error) {alert(error);}, 
	"ExifImagePlugin",
    "exif",
    []);
}